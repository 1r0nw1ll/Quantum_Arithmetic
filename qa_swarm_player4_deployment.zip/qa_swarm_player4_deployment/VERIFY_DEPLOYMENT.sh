#!/bin/bash
#
# QA Swarm - Deployment Verification Script
# Verifies that player4 has successfully joined the swarm
#

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

echo -e "${CYAN}╔════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║   QA Swarm Deployment Verification            ║${NC}"
echo -e "${CYAN}╚════════════════════════════════════════════════╝${NC}"
echo ""

INSTALL_DIR="$HOME/qa_lab"
PASS_COUNT=0
FAIL_COUNT=0

# Helper function
check_test() {
    local test_name="$1"
    local command="$2"

    echo -n "Testing: $test_name... "

    if eval "$command" > /dev/null 2>&1; then
        echo -e "${GREEN}✓ PASS${NC}"
        ((PASS_COUNT++))
        return 0
    else
        echo -e "${RED}✗ FAIL${NC}"
        ((FAIL_COUNT++))
        return 1
    fi
}

# Test 1: Installation directory exists
echo -e "${YELLOW}[1/10]${NC} Installation Directory"
check_test "qa_lab directory exists" "[ -d $INSTALL_DIR ]"
if [ -d "$INSTALL_DIR" ]; then
    echo "  Location: $INSTALL_DIR"
fi
echo ""

# Test 2: Node identity file
echo -e "${YELLOW}[2/10]${NC} Node Identity"
check_test "Node config file exists" "[ -f $INSTALL_DIR/.node_config.json ]"
if [ -f "$INSTALL_DIR/.node_config.json" ]; then
    echo "  Node Identity:"
    cat "$INSTALL_DIR/.node_config.json" | python3 -m json.tool 2>/dev/null || cat "$INSTALL_DIR/.node_config.json"
fi
echo ""

# Test 3: Python environment
echo -e "${YELLOW}[3/10]${NC} Python Environment"
check_test "Virtual environment exists" "[ -d $INSTALL_DIR/qa_venv ]"
check_test "Python executable works" "$INSTALL_DIR/qa_venv/bin/python --version"
if [ -x "$INSTALL_DIR/qa_venv/bin/python" ]; then
    echo "  Python version: $($INSTALL_DIR/qa_venv/bin/python --version)"
fi
echo ""

# Test 4: Dependencies
echo -e "${YELLOW}[4/10]${NC} Python Dependencies"
if [ -x "$INSTALL_DIR/qa_venv/bin/python" ]; then
    source "$INSTALL_DIR/qa_venv/bin/activate"
    check_test "PyYAML installed" "python -c 'import yaml'"
    check_test "NumPy installed" "python -c 'import numpy'"
    check_test "Matplotlib installed" "python -c 'import matplotlib'"
    deactivate
fi
echo ""

# Test 5: Compute node configuration
echo -e "${YELLOW}[5/10]${NC} Compute Node Configuration"
check_test "Makefile.node exists" "[ -f $INSTALL_DIR/Makefile.node ]"
if [ -f "$INSTALL_DIR/Makefile.node" ]; then
    echo "  Compute node targets:"
    grep "node-agent-loop:" "$INSTALL_DIR/Makefile.node"
fi
echo ""

# Test 6: Systemd service
echo -e "${YELLOW}[6/10]${NC} Swarm Daemon"
check_test "Systemd service exists" "[ -f /etc/systemd/system/qa-swarm-node.service ]"
check_test "Daemon is enabled" "systemctl is-enabled qa-swarm-node"
check_test "Daemon is active" "systemctl is-active qa-swarm-node"

if systemctl is-active qa-swarm-node >/dev/null 2>&1; then
    echo "  Daemon status:"
    systemctl status qa-swarm-node --no-pager -l -n 3 | tail -5
fi
echo ""

# Test 7: Syncthing
echo -e "${YELLOW}[7/10]${NC} Syncthing Synchronization"
check_test "Syncthing is running" "pgrep -x syncthing"
check_test "Syncthing API responds" "curl -s http://localhost:8384/rest/system/status"

if curl -s http://localhost:8384/rest/system/status >/dev/null 2>&1; then
    echo "  Syncthing status:"
    curl -s http://localhost:8384/rest/system/status | python3 -m json.tool 2>/dev/null | grep -E '(myID|uptime)' | head -2
fi
echo ""

# Test 8: Task directories
echo -e "${YELLOW}[8/10]${NC} Task Directories"
check_test "tasks/inbox exists" "[ -d $INSTALL_DIR/tasks/inbox ]"
check_test "tasks/active exists" "[ -d $INSTALL_DIR/tasks/active ]"
check_test "tasks/completed exists" "[ -d $INSTALL_DIR/tasks/completed ]"

if [ -d "$INSTALL_DIR/tasks" ]; then
    echo "  Task counts:"
    echo "    Inbox: $(ls -1 $INSTALL_DIR/tasks/inbox/*.yaml 2>/dev/null | wc -l) tasks"
    echo "    Active: $(ls -1 $INSTALL_DIR/tasks/active/*.yaml 2>/dev/null | wc -l) tasks"
    echo "    Completed: $(ls -1 $INSTALL_DIR/tasks/completed/*.yaml 2>/dev/null | wc -l) tasks"
fi
echo ""

# Test 9: Connectivity to primary
echo -e "${YELLOW}[9/10]${NC} Primary Node Connectivity"
PRIMARY_NODE=$(cat "$INSTALL_DIR/.node_config.json" 2>/dev/null | python3 -c "import sys, json; print(json.load(sys.stdin).get('primary_node', 'player2'))" 2>/dev/null || echo "player2")

check_test "Can ping primary ($PRIMARY_NODE)" "ping -c 1 $PRIMARY_NODE"
check_test "Can SSH to primary" "ssh -o ConnectTimeout=5 -o BatchMode=yes $PRIMARY_NODE 'echo ok'"
echo ""

# Test 10: Recent daemon activity
echo -e "${YELLOW}[10/10]${NC} Recent Daemon Activity"
if systemctl is-active qa-swarm-node >/dev/null 2>&1; then
    echo "  Recent logs (last 20 lines):"
    journalctl -u qa-swarm-node -n 20 --no-pager | tail -15

    # Check if agent loop has run
    if journalctl -u qa-swarm-node -n 100 --no-pager | grep -q "agent loop"; then
        echo -e "  ${GREEN}✓${NC} Agent loop has executed"
        ((PASS_COUNT++))
    else
        echo -e "  ${YELLOW}⚠${NC}  Agent loop not yet visible in logs (may still be starting)"
    fi
else
    echo -e "  ${RED}✗${NC} Daemon not running - cannot check activity"
    ((FAIL_COUNT++))
fi
echo ""

# Final summary
echo ""
echo -e "${CYAN}╔════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║          Verification Summary                  ║${NC}"
echo -e "${CYAN}╚════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "Tests Passed: ${GREEN}$PASS_COUNT${NC}"
echo -e "Tests Failed: ${RED}$FAIL_COUNT${NC}"
echo ""

if [ $FAIL_COUNT -eq 0 ]; then
    echo -e "${GREEN}✅ DEPLOYMENT SUCCESSFUL${NC}"
    echo ""
    echo "player4 has successfully joined the distributed swarm!"
    echo ""
    echo "Next steps on primary node (player2):"
    echo "  cd ~/signal_experiments/qa_lab"
    echo "  make cluster-monitor    # See player4 in cluster"
    echo "  make cluster-dispatch   # Route tasks to player4"
    echo ""
    exit 0
else
    echo -e "${YELLOW}⚠️  DEPLOYMENT INCOMPLETE${NC}"
    echo ""
    echo "Some tests failed. Please review the output above."
    echo "Common fixes:"
    echo "  - Restart daemon: sudo systemctl restart qa-swarm-node"
    echo "  - Check Syncthing config: http://localhost:8384"
    echo "  - View detailed logs: journalctl -u qa-swarm-node -f"
    echo ""
    exit 1
fi
