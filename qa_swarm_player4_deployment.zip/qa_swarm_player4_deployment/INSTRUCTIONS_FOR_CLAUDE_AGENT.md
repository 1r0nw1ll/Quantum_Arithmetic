# 🤖 Instructions for Claude CLI Agent on player4

**Task:** Deploy this node as a compute node in the QA distributed swarm.

**Primary Node:** player2
**Your Role:** Compute node (executor + reviewer + benchmarks)

---

## 📋 Your Mission

Execute the automated deployment script to join player4 to the distributed QA swarm managed by player2.

---

## 🚀 Step-by-Step Instructions

### Step 1: Verify Deployment Package

First, confirm you have the deployment package:

```bash
ls -la
```

You should see:
- `DEPLOY_ON_PLAYER4.sh` (main deployment script)
- `INSTRUCTIONS_FOR_CLAUDE_AGENT.md` (this file)
- `VERIFY_DEPLOYMENT.sh` (verification script)

### Step 2: Make Deployment Script Executable

```bash
chmod +x DEPLOY_ON_PLAYER4.sh
chmod +x VERIFY_DEPLOYMENT.sh
```

### Step 3: Run Deployment Script

```bash
bash DEPLOY_ON_PLAYER4.sh
```

**What will happen:**
1. ✅ Check prerequisites (Python, Git)
2. ✅ Test connectivity to player2
3. ✅ Clone QA Lab codebase from player2
4. ✅ Setup Python virtual environment
5. ✅ Install dependencies
6. ✅ Configure Syncthing (requires manual step - see below)
7. ✅ Create compute node configuration
8. ✅ Generate node identity file
9. ✅ Launch swarm daemon

### Step 4: Syncthing Configuration (Manual Step)

When the script reaches the Syncthing setup, it will pause and display:

```
📋 SYNCTHING CONFIGURATION REQUIRED:
   Open two browser tabs:
   1. http://player4:8384 (this machine)
   2. http://player2:8384 (primary node)
```

**You need to:**

**On player4's Syncthing UI (http://player4:8384):**
1. Click "Actions" → "Show ID" → Copy the device ID
2. Wait for player2 to add you as a remote device
3. Accept the connection when prompted
4. Accept folder shares when offered: `tasks/`, `artifacts/`, `plots/`, `logs/`

**On player2's Syncthing UI (http://player2:8384):**
1. Click "Add Remote Device"
2. Paste player4's device ID
3. Click "Add Folder" and share: `~/signal_experiments/qa_lab/tasks`
4. Repeat for: `artifacts/`, `plots/`, `logs/`
5. Select player4 as the device to share with

**Wait for "Up to Date" status** on all folders (should take 1-5 minutes)

Then press Enter in the deployment script to continue.

### Step 5: Verify Deployment

```bash
bash VERIFY_DEPLOYMENT.sh
```

This will check:
- ✅ Node identity file exists
- ✅ Python environment is set up
- ✅ Swarm daemon is running
- ✅ Syncthing is syncing
- ✅ Node is visible to cluster monitor

### Step 6: Monitor Operation

Watch the swarm in action:

```bash
# View daemon logs
journalctl -u qa-swarm-node -f

# Or check status
systemctl status qa-swarm-node
```

---

## 🎯 Expected Results

After successful deployment, you should see:

**1. Node Identity Created:**
```json
{
  "node_type": "compute",
  "node_id": "player4",
  "primary_node": "player2",
  "capabilities": [
    "executor",
    "reviewer",
    "rust_benchmarks",
    "metrics_generation"
  ]
}
```

**2. Daemon Running:**
```bash
$ systemctl status qa-swarm-node
● qa-swarm-node.service - QA Lab Swarm Compute Node
   Loaded: loaded
   Active: active (running)
```

**3. Tasks Syncing:**
```bash
$ ls ~/qa_lab/tasks/active | wc -l
434  # Should match player2's task count
```

**4. Logs Showing Activity:**
```
🖥️  QA Compute Node: Starting agent loop...
📥 Checking for assigned tasks...
   Found 10 tasks with node_id: player4
   Executing task: exp-jepa-integration-...
✅ Task completed successfully
```

---

## ✅ Success Criteria

Deployment is successful when:

- [x] `systemctl status qa-swarm-node` shows "active (running)"
- [x] `~/qa_lab/.node_config.json` exists with correct node_id
- [x] Syncthing shows "Up to Date" for all folders
- [x] `journalctl -u qa-swarm-node -f` shows agent loop executing
- [x] Tasks directory is populated: `ls ~/qa_lab/tasks/active`

---

## 🚨 Troubleshooting

### Problem: Cannot reach player2

**Solution:**
```bash
# Test connectivity
ping player2
ssh player2 "echo 'SSH works'"

# If SSH requires password, make sure you can authenticate
```

### Problem: Syncthing not starting

**Solution:**
```bash
# Start manually
syncthing serve &

# Open UI
xdg-open http://localhost:8384
```

### Problem: Daemon fails to start

**Solution:**
```bash
# Check logs
journalctl -u qa-swarm-node -n 50

# Restart
sudo systemctl restart qa-swarm-node

# Run manually for debugging
cd ~/qa_lab
source qa_venv/bin/activate
make -f Makefile.node node-agent-loop
```

### Problem: Dependencies missing

**Solution:**
```bash
cd ~/qa_lab
source qa_venv/bin/activate
pip install pyyaml numpy matplotlib torch tqdm scipy
```

---

## 📊 Verification Commands

After deployment, run these to confirm everything works:

```bash
# 1. Check node identity
cat ~/qa_lab/.node_config.json

# 2. Check daemon status
systemctl status qa-swarm-node

# 3. Check Syncthing status
curl http://localhost:8384/rest/system/status 2>/dev/null | python3 -m json.tool

# 4. Check task directory
ls ~/qa_lab/tasks/active | head -10

# 5. Watch logs
journalctl -u qa-swarm-node -f
```

---

## 🔥 What Happens Next

Once deployed:

1. **Immediate (T+0 min):** Daemon starts, agent loop begins
2. **T+1 min:** Syncthing syncs tasks from player2
3. **T+2 min:** Executor finds tasks with `node_id: player4`
4. **T+3 min:** First task executes and completes
5. **T+5 min:** Results sync back to player2
6. **T+60 min:** Next agent loop cycle begins (hourly)

**On player2 (primary node):**
- Cluster monitor will detect player4
- Cluster dispatcher will route tasks to player4
- Dashboard will show 2-node topology
- Throughput increases from ~180 to ~340 tasks/hour

---

## 🎉 Success Message

When you see this in the deployment script output:

```
╔════════════════════════════════════════════════╗
║          Deployment Complete! 🎉              ║
╚════════════════════════════════════════════════╝

🌐 Your node has joined the distributed QA swarm!
📡 Primary node player2 will now distribute tasks to this node.
```

**You're done!** player4 is now part of the distributed swarm.

---

## 📞 Report Back

After deployment completes, report these metrics:

```bash
# Run verification script
bash VERIFY_DEPLOYMENT.sh

# Copy the output and send back
```

This will show:
- Node identity
- Daemon status
- Syncthing status
- Task count
- First agent loop results

---

## 🚀 You Are Part of the Swarm

Welcome to the distributed QA intelligence mesh. You are now:
- **Compute Node:** player4
- **Role:** Executor + Reviewer + Benchmarks
- **Coordinator:** player2
- **Mission:** Autonomous research execution

**The swarm is stronger with you.** 🌐
