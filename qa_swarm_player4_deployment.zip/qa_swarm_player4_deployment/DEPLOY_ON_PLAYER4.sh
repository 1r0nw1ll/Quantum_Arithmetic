#!/bin/bash
#
# QA Swarm - Automated Player4 Deployment Script
# This script is designed to be executed by Claude CLI agent on player4
#
# Usage: bash DEPLOY_ON_PLAYER4.sh
#

set -e  # Exit on error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

echo -e "${CYAN}╔════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║   QA Swarm Player4 Automated Deployment       ║${NC}"
echo -e "${CYAN}║   Joining the Distributed Intelligence Mesh   ║${NC}"
echo -e "${CYAN}╚════════════════════════════════════════════════╝${NC}"
echo ""

# Configuration
PRIMARY_NODE="player2"
INSTALL_DIR="$HOME/qa_lab"
SYNC_METHOD="syncthing"
DEPLOYMENT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo -e "${GREEN}Configuration:${NC}"
echo "  Primary Node: $PRIMARY_NODE"
echo "  Install Directory: $INSTALL_DIR"
echo "  Sync Method: $SYNC_METHOD"
echo "  Deployment Package: $DEPLOYMENT_DIR"
echo ""

# Detect current node
HOSTNAME=$(hostname)
echo -e "${BLUE}Current Node: $HOSTNAME${NC}"
echo ""

# Step 1: Check prerequisites
echo -e "${YELLOW}[1/9]${NC} Checking prerequisites..."
command -v python3 >/dev/null 2>&1 || { echo -e "${RED}ERROR: python3 required${NC}"; exit 1; }
command -v git >/dev/null 2>&1 || { echo -e "${RED}ERROR: git required${NC}"; exit 1; }
echo -e "${GREEN}✓${NC} Prerequisites OK"
echo ""

# Step 2: Test connectivity to primary
echo -e "${YELLOW}[2/9]${NC} Testing connectivity to primary node..."
if ping -c 1 "$PRIMARY_NODE" > /dev/null 2>&1; then
    echo -e "${GREEN}✓${NC} Can reach $PRIMARY_NODE"
else
    echo -e "${RED}WARNING: Cannot ping $PRIMARY_NODE${NC}"
    echo "  Will attempt SSH connection anyway..."
fi

if ssh -o ConnectTimeout=5 -o BatchMode=yes "$PRIMARY_NODE" "echo 'SSH OK'" 2>/dev/null; then
    echo -e "${GREEN}✓${NC} SSH connection to $PRIMARY_NODE working"
else
    echo -e "${YELLOW}⚠${NC}  SSH requires authentication - will prompt for password"
fi
echo ""

# Step 3: Clone/sync codebase from primary
echo -e "${YELLOW}[3/9]${NC} Setting up QA Lab codebase..."
if [ -d "$INSTALL_DIR" ]; then
    echo -e "${YELLOW}Directory exists. Updating...${NC}"
    cd "$INSTALL_DIR"
    git pull 2>/dev/null || echo "Not a git repo, will sync via $SYNC_METHOD"
else
    echo -e "${YELLOW}Cloning from primary node...${NC}"
    # Try to clone via SSH from primary
    if ssh "$PRIMARY_NODE" "test -d ~/signal_experiments/qa_lab/.git" 2>/dev/null; then
        git clone "ssh://${PRIMARY_NODE}/~/signal_experiments/qa_lab" "$INSTALL_DIR" || {
            echo -e "${YELLOW}Git clone failed, using direct copy${NC}"
            mkdir -p "$INSTALL_DIR"
            scp -r "${PRIMARY_NODE}:~/signal_experiments/qa_lab/"* "$INSTALL_DIR/" || {
                echo -e "${RED}ERROR: Cannot access primary node${NC}"
                echo "  Please ensure SSH keys are set up or password access is available"
                exit 1
            }
        }
    else
        mkdir -p "$INSTALL_DIR"
        echo -e "${YELLOW}Copying codebase from primary...${NC}"
        scp -r "${PRIMARY_NODE}:~/signal_experiments/qa_lab/"* "$INSTALL_DIR/" || {
            echo -e "${RED}ERROR: Cannot copy from primary node${NC}"
            exit 1
        }
    fi
fi
cd "$INSTALL_DIR"
echo -e "${GREEN}✓${NC} Codebase ready at $INSTALL_DIR"
echo ""

# Step 4: Create Python virtual environment
echo -e "${YELLOW}[4/9]${NC} Setting up Python virtual environment..."
if [ ! -d "qa_venv" ]; then
    python3 -m venv qa_venv
fi
source qa_venv/bin/activate
pip install --upgrade pip wheel -q
echo -e "${GREEN}✓${NC} Virtual environment ready"
echo ""

# Step 5: Install dependencies
echo -e "${YELLOW}[5/9]${NC} Installing dependencies..."
if [ -f "requirements.txt" ]; then
    pip install -r requirements.txt -q
else
    # Install common dependencies
    pip install pyyaml numpy matplotlib torch tqdm scipy -q
fi
echo -e "${GREEN}✓${NC} Dependencies installed"
echo ""

# Step 6: Setup sync method
echo -e "${YELLOW}[6/9]${NC} Setting up state synchronization ($SYNC_METHOD)..."

if [ "$SYNC_METHOD" = "syncthing" ]; then
    # Check if Syncthing is installed
    if ! command -v syncthing &> /dev/null; then
        echo -e "${YELLOW}Installing Syncthing...${NC}"

        # Detect OS and install accordingly
        if [[ "$OSTYPE" == "linux-gnu"* ]]; then
            if command -v apt-get &> /dev/null; then
                sudo apt-get update -qq
                sudo apt-get install -y syncthing -qq
            elif command -v yum &> /dev/null; then
                sudo yum install -y syncthing
            else
                echo -e "${YELLOW}Please install Syncthing manually: https://syncthing.net/downloads/${NC}"
                echo "  Then re-run this script"
                exit 1
            fi
        else
            echo -e "${YELLOW}Please install Syncthing manually: https://syncthing.net/downloads/${NC}"
            echo "  Then re-run this script"
            exit 1
        fi
    fi

    # Create sync directories
    mkdir -p tasks/{inbox,active,completed,rejected}
    mkdir -p artifacts/{evals,proofs,ingestion,overleaf}
    mkdir -p plots logs

    echo -e "${GREEN}✓${NC} Syncthing installed"
    echo ""
    echo -e "${BLUE}📋 SYNCTHING CONFIGURATION REQUIRED:${NC}"
    echo "   The deployment will pause for Syncthing setup."
    echo "   Open two browser tabs:"
    echo ""
    echo "   1. http://$HOSTNAME:8384 (this machine)"
    echo "   2. http://$PRIMARY_NODE:8384 (primary node)"
    echo ""
    echo "   On both interfaces:"
    echo "   - Add the other machine as a remote device"
    echo "   - Share these folders: tasks/, artifacts/, plots/, logs/"
    echo "   - Wait for 'Up to Date' status"
    echo ""

    # Start Syncthing in background
    echo -e "${YELLOW}Starting Syncthing...${NC}"
    syncthing serve &
    SYNCTHING_PID=$!
    sleep 5

    echo -e "${CYAN}Syncthing is running on http://localhost:8384${NC}"
    echo -e "${CYAN}Syncthing PID: $SYNCTHING_PID${NC}"
    echo ""
    echo -e "${YELLOW}Press Enter when Syncthing configuration is complete...${NC}"
    read

elif [ "$SYNC_METHOD" = "nfs" ]; then
    echo -e "${YELLOW}NFS setup requires manual configuration${NC}"
    echo "  See DISTRIBUTED_SWARM_GUIDE.md for NFS setup instructions"
    exit 1
fi
echo ""

# Step 7: Configure as compute node
echo -e "${YELLOW}[7/9]${NC} Configuring as compute node..."

# Create compute node Makefile override
cat > Makefile.node <<'EOF'
# QA Swarm Compute Node Configuration
# This node focuses on execution, not coordination

.PHONY: node-agent-loop node-daemon

VENV := qa_venv
PYTHON := $(VENV)/bin/python

# Compute node only runs execution stages
node-agent-loop:
	@echo "🖥️  QA Compute Node: Starting agent loop..."
	@echo "📥 Checking for assigned tasks..."
	$(PYTHON) qa_agents/cli/executor.py || true
	@echo "👀 Reviewing completed work..."
	$(PYTHON) qa_agents/cli/reviewer.py || true
	@echo "🦀 Running Rust benchmarks..."
	$(MAKE) port-rust-all || true
	@echo "📊 Generating local metrics..."
	$(PYTHON) qa_fast_eval.py || true
	@echo "✅ Compute node cycle complete"

# Daemon for compute node (1-hour cycles)
node-daemon:
	@echo "🔁 Starting compute node daemon (Ctrl+C to stop)..."
	@while true; do \
		$(MAKE) -f Makefile.node node-agent-loop || true; \
		sleep 3600; \
	done
EOF

echo -e "${GREEN}✓${NC} Compute node configuration created"
echo ""

# Step 8: Create node identity file
echo -e "${YELLOW}[8/9]${NC} Creating node identity..."
cat > .node_config.json <<EOF
{
  "node_type": "compute",
  "node_id": "$HOSTNAME",
  "primary_node": "$PRIMARY_NODE",
  "sync_method": "$SYNC_METHOD",
  "installed_at": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "capabilities": [
    "executor",
    "reviewer",
    "rust_benchmarks",
    "metrics_generation"
  ],
  "hardware": {
    "hostname": "$HOSTNAME",
    "cpu_cores": $(nproc 2>/dev/null || echo 4),
    "architecture": "$(uname -m)"
  }
}
EOF
echo -e "${GREEN}✓${NC} Node identity created: .node_config.json"
cat .node_config.json
echo ""

# Step 9: Launch daemon
echo -e "${YELLOW}[9/9]${NC} Launching swarm daemon..."

# Create systemd service for automatic startup
echo -e "${YELLOW}Creating systemd service...${NC}"
cat > /tmp/qa-swarm-node.service <<EOF
[Unit]
Description=QA Lab Swarm Compute Node
After=network.target

[Service]
Type=simple
User=$USER
WorkingDirectory=$INSTALL_DIR
Environment="PATH=$INSTALL_DIR/qa_venv/bin:/usr/local/bin:/usr/bin:/bin"
ExecStart=/usr/bin/make -f $INSTALL_DIR/Makefile.node node-daemon
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

sudo mv /tmp/qa-swarm-node.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable qa-swarm-node
sudo systemctl start qa-swarm-node

echo -e "${GREEN}✓${NC} Daemon launched"
echo ""

# Final summary
echo ""
echo -e "${CYAN}╔════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║          Deployment Complete! 🎉              ║${NC}"
echo -e "${CYAN}╚════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${GREEN}Node Type:${NC} Compute Node"
echo -e "${GREEN}Node ID:${NC} $HOSTNAME"
echo -e "${GREEN}Primary Node:${NC} $PRIMARY_NODE"
echo -e "${GREEN}Install Dir:${NC} $INSTALL_DIR"
echo -e "${GREEN}Sync Method:${NC} $SYNC_METHOD"
echo ""
echo -e "${YELLOW}Daemon Management:${NC}"
echo "  Status:  systemctl status qa-swarm-node"
echo "  Logs:    journalctl -u qa-swarm-node -f"
echo "  Stop:    systemctl stop qa-swarm-node"
echo "  Restart: systemctl restart qa-swarm-node"
echo ""
echo -e "${YELLOW}Manual Testing:${NC}"
echo "  cd $INSTALL_DIR"
echo "  source qa_venv/bin/activate"
echo "  make -f Makefile.node node-agent-loop"
echo ""
echo -e "${BLUE}🌐 Your node has joined the distributed QA swarm!${NC}"
echo -e "${BLUE}📡 Primary node $PRIMARY_NODE will now distribute tasks to this node.${NC}"
echo ""
echo -e "${GREEN}Next: On $PRIMARY_NODE, run:${NC}"
echo "  make cluster-monitor    # See this node in cluster"
echo "  make cluster-dispatch   # Distribute tasks to this node"
echo ""
